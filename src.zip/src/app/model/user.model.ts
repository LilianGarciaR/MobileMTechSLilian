export interface User {
    Id: number;
    Name: string;
    Email: string;
}